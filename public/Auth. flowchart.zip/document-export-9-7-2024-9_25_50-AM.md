# ZizTv Auth Flowchart



